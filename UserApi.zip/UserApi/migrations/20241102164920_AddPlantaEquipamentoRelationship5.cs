﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace UserApi.Migrations
{
    /// <inheritdoc />
    public partial class AddPlantaEquipamentoRelationship5 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Plantas_EquipamentoId",
                table: "Plantas",
                column: "EquipamentoId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Plantas_UsuarioId",
                table: "Plantas",
                column: "UsuarioId");

            migrationBuilder.AddForeignKey(
                name: "FK_Plantas_Equipamentos_EquipamentoId",
                table: "Plantas",
                column: "EquipamentoId",
                principalTable: "Equipamentos",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Plantas_Usuarios_UsuarioId",
                table: "Plantas",
                column: "UsuarioId",
                principalTable: "Usuarios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Plantas_Equipamentos_EquipamentoId",
                table: "Plantas");

            migrationBuilder.DropForeignKey(
                name: "FK_Plantas_Usuarios_UsuarioId",
                table: "Plantas");

            migrationBuilder.DropIndex(
                name: "IX_Plantas_EquipamentoId",
                table: "Plantas");

            migrationBuilder.DropIndex(
                name: "IX_Plantas_UsuarioId",
                table: "Plantas");
        }
    }
}
