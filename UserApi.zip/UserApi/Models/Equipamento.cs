// Models/Leitura.cs
using System;
using System.ComponentModel.DataAnnotations;

namespace UserApi.Models
{
    public class Equipamento
    {
        [Key]
        public int Id { get; set; }
        
        [MaxLength(255)]
        public string? Nome { get; set; }

        [MaxLength(255)]
        public string? Descricao {get; set;}      
    }
}
