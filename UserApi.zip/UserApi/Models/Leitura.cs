// Models/Leitura.cs
using System;
using System.ComponentModel.DataAnnotations;

namespace UserApi.Models
{
    public class Leitura
    {
        [Key]
        public int Id { get; set; }
        
        [Required]
        public DateTime DataLeitura { get; set; }

        [Required]
        public double Temperatura { get; set; }
        
        [Required]
        public double Luminosidade { get; set; }
        
        [Required]
        public double Umidade { get; set; }

        public int EquipamentoId { get; set; }
    }
}
