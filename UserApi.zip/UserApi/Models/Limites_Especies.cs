// Models/Leitura.cs
using System;
using System.ComponentModel.DataAnnotations;

namespace UserApi.Models
{
    public class Limites_Especies
    {
        [Key]
        public int Id { get; set; }
        
        [Required]
        public string? Especie { get; set; }

        public double MaxTemperatura { get; set; }
        public double MinTemperatura { get; set; }
        
        public double MaxLuminosidade { get; set; }
        public double MinLuminosidade { get; set; }
        
        public double MaxUmidade { get; set; }
        public double MinUmidade { get; set; }
        public double MaxMediaSemanaUmidade { get; set; }
        public double MinMediaSemanaUmidade { get; set; }
    }
}
