// Models/Planta.cs
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace UserApi.Models
{
    public class Planta
    {
        [Key]
        public int Id { get; set; }

        [ForeignKey("Usuario")]
        public int UsuarioId { get; set; }  // FK para a tabela Usuario

        [ForeignKey("Equipamento")]
        public int? EquipamentoId { get; set; }  // FK para a tabela Planta

        [Required]
        [MaxLength(255)]
        public string? Nome { get; set; }

        [Required]
        [MaxLength(255)]
        public string? Especie { get; set; }

        [MaxLength(255)]
        public string? Descricao { get; set; }

        public DateTime DataCadastro { get; set; }
        public DateTime DataUpdate { get; set; }

        public string? Imagem { get; set; }
    }
}
