using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UserApi.Data;
using UserApi.Models;

[Route("api/[controller]")]
[ApiController]
public class PlantaController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public PlantaController(ApplicationDbContext context)
    {
        _context = context;
    }

    // GET: api/Plantas
    [HttpGet("GetPlantas/{userId}")]
    public async Task<ActionResult<IEnumerable<Planta>>> GetPlantas(int userId)
    {
        var plantas = await _context.Plantas
        .Where(p => p.UsuarioId == userId)
        .ToListAsync();

        if (!plantas.Any())
        {
            return NotFound();
        }

        return Ok(plantas);
    }

    // GET: api/Plantas/5
    [HttpGet("{id}")]
    public async Task<ActionResult<Planta>> GetPlanta(int id)
    {
        var planta = await _context.Plantas.FindAsync(id);
        if (planta == null)
        {
            return NotFound();
        }
        return planta;
    }

    // POST: api/Plantas
    [HttpPost]
    public async Task<ActionResult<Planta>> PostPlanta(Planta planta)
    {
        if (ModelState.IsValid)
        {
            planta.DataCadastro = DateTime.Now;
            planta.DataUpdate = DateTime.Now;
            
            _context.Plantas.Add(planta);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetPlanta", new { id = planta.Id }, planta);
        }

        return BadRequest(ModelState);
    }
}
