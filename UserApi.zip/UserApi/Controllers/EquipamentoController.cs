using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UserApi.Data;
using UserApi.Models;

namespace UserApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EquipamentoController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public EquipamentoController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/Leituras
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Equipamento>>> GetEquipamentos()
        {
            return await _context.Equipamentos.ToListAsync();
        }

        // GET: api/Leituras/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Equipamento>> GetEquipamento(int id)
        {
            var equipamento = await _context.Equipamentos.FindAsync(id);

            if (equipamento == null)
            {
                return NotFound();
            }

            return equipamento;
        }

        [HttpGet("GetEquip/{equipamentoName}")]
        public async Task<ActionResult<Equipamento>> GetEquipamentoByName(string equipamentoName)
        {
            var equipamento = await _context.Equipamentos.Where(l => l.Nome == equipamentoName).FirstOrDefaultAsync();

            if (equipamento == null)
            {
                return NotFound();
            }

            return Ok(equipamento);
        }

        // POST: api/Leituras
        [HttpPost]
        public async Task<ActionResult<Equipamento>> PostEquipamento(Equipamento equipamento)
        {
            _context.Equipamentos.Add(equipamento);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetEquipamento", new { id = equipamento.Id }, equipamento);
        }
    }
}
