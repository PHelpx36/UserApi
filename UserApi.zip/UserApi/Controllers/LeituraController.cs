// Controllers/LeiturasController.cs
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UserApi.Data;
using UserApi.Models;

namespace UserApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LeituraController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public LeituraController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/Leituras
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Leitura>>> GetLeituras()
        {
            return await _context.Leitura.ToListAsync();
        }

        // GET: api/Leituras/5
        [HttpGet("{equipamentoId}")]
        public async Task<ActionResult<IEnumerable<Leitura>>> GetLeiturasByEquipamentoId(int equipamentoId)
        {
            var leituras = await _context.Leitura
                .Where(l => l.EquipamentoId == equipamentoId)
                .ToListAsync();

            if (leituras == null || !leituras.Any())
            {
                return NotFound();
            }

            return Ok(leituras);
        }
        
        // POST: api/Leituras
        [HttpPost]
        public async Task<ActionResult<Leitura>> PostLeitura(Leitura leitura)
        {
            _context.Leitura.Add(leitura);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetLeitura", new { id = leitura.Id }, leitura);
        }
    }
}
